﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main()
        {
            // Ввод матрицы 10x10
            double[,] C = new double[10, 10];
            Console.WriteLine("Введите элементы матрицы 10x10 (дробные числа вводите через запятую):");

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    bool validInput = false;
                    while (!validInput)
                    {
                        Console.Write($"C[{i},{j}] = ");
                        string input = Console.ReadLine();

                        if (double.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out double value))
                        {
                            C[i, j] = value;
                            validInput = true;
                        }
                        else
                        {
                            Console.WriteLine("Введенное вами число не было распознано. Попробуйте еще раз.");
                        }
                    }
                }
            }

            // 1) Сумма положительных элементов в заштрихованной области
            double sumPositive = 0;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j <= i; j++) // Заштрихованная область: элементы под главной диагональю
                {
                    if (C[i, j] > 0)
                    {
                        sumPositive += C[i, j];
                    }
                }
            }

            // 2) Массив L из элементов заштрихованной области, меньших -3
            int countL = 0;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    if (C[i, j] < -3)
                    {
                        countL++;
                    }
                }
            }

            double[] L = new double[countL];
            int indexL = 0;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    if (C[i, j] < -3)
                    {
                        L[indexL] = C[i, j];
                        indexL++;
                    }
                }
            }

            // 3) Массив Q из количеств отрицательных элементов в каждой строке заштрихованной области
            int[] Q = new int[10];
            for (int i = 0; i < 10; i++)
            {
                int countNegative = 0;
                for (int j = 0; j <= i; j++)
                {
                    if (C[i, j] < 0)
                    {
                        countNegative++;
                    }
                }
                Q[i] = countNegative;
            }

            // 4) Минимальный отрицательный элемент в левой половине матрицы
            double minNegative = double.MaxValue;
            bool foundNegative = false;

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 5; j++) // Левая половина: столбцы 0-4
                {
                    if (C[i, j] < 0 && C[i, j] < minNegative)
                    {
                        minNegative = C[i, j];
                        foundNegative = true;
                    }
                }
            }

            // Вывод результатов
            Console.WriteLine("\n=== РЕЗУЛЬТАТЫ ===");

            // Вывод исходной матрицы
            Console.WriteLine("\nИсходная матрица C:");
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Console.Write($"{C[i, j],10:F3}");
                }
                Console.WriteLine();
            }

            Console.WriteLine($"\n1) Сумма положительных элементов в заштрихованной области: {sumPositive:F6}");

            Console.WriteLine("\n2) Массив L (элементы заштрихованной области < -3):");
            if (L.Length > 0)
            {
                foreach (double element in L)
                {
                    Console.Write($"{element:F6} ");
                }
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Нет элементов, удовлетворяющих условию");
            }

            Console.WriteLine("\n3) Массив Q (количества отрицательных элементов по строкам заштрихованной области):");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Строка {i}: {Q[i]} отрицательных элементов");
            }

            Console.WriteLine("\n4) Минимальный отрицательный элемент в левой половине матрицы:");
            if (foundNegative)
            {
                Console.WriteLine($"{minNegative:F6}");
            }
            else
            {
                Console.WriteLine("Отрицательные элементы не найдены");
            }
        }
    }
}
