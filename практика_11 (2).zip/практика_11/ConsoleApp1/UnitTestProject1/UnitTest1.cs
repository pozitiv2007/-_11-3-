﻿using ConsoleApp1;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Globalization;

namespace UnitTestProject1
{
    [TestClass]
    public class MatrixInputTests
    {
        [TestMethod]
        public void DoubleTryParse_WithLargePositiveInteger_ReturnsTrue()
        {
            // Большое целое положительное число
            bool result = double.TryParse("999999999999999999", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(999999999999999999, value);
        }

        [TestMethod]
        public void DoubleTryParse_WithLargeNegativeInteger_ReturnsTrue()
        {
            // Большое целое отрицательное число
            bool result = double.TryParse("-9999999999999999", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(-9999999999999999, value);
        }

        [TestMethod]
        public void DoubleTryParse_WithSmallNegativeInteger_ReturnsTrue()
        {
            // Маленькое целое отрицательное число
            bool result = double.TryParse("-5", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(-5, value);
        }

        [TestMethod]
        public void DoubleTryParse_WithSmallPositiveInteger_ReturnsTrue()
        {
            // Маленькое целое положительное число
            bool result = double.TryParse("5", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(5, value);
        }

        [TestMethod]
        public void DoubleTryParse_WithEmptyString_ReturnsFalse()
        {
            // Пустая строка
            bool result = double.TryParse("", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsFalse(result);
            Assert.AreEqual(0, value);
        }
        [TestMethod]
        public void DoubleTryParse_WithNonNumericCharacters_ReturnsFalse()
        {
            // Символы (не числа)
            bool result = double.TryParse("abc", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsFalse(result);
            Assert.AreEqual(0, value);
        }

        [TestMethod]
        public void DoubleTryParse_WithLargePositiveDecimal_ReturnsTrue()
        {
            // Большое дробное положительное числел
            bool result = double.TryParse("999999999999999999999.999999999", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(999999999999999999999.999999999, value, 0.000001);
        }

        [TestMethod]
        public void DoubleTryParse_WithLargeNegativeDecimal_ReturnsTrue()
        {
            // Большое дробное отрицательное число
            bool result = double.TryParse("-999999999999999999999.999999999", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(-999999999999999999999.999999999, value, 0.000001);
        }

        [TestMethod]
        public void DoubleTryParse_WithSmallNegativeDecimal_ReturnsTrue()
        {
            // Маленькое дробное отрицательное число
            bool result = double.TryParse("-0.000123", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(-0.000123, value, 0.0000001);
        }

        [TestMethod]
        public void DoubleTryParse_WithSmallPositiveDecimal_ReturnsTrue()
        {
            // Маленькое дробное положительное число
            bool result = double.TryParse("0.000456", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(0.000456, value, 0.0000001);
        }

        [TestMethod]
        public void DoubleTryParse_WithNegativeZero_ReturnsTrue()
        {
            // ноль
            bool result = double.TryParse("-0", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsTrue(result);
            Assert.AreEqual(0, value); // -0 преобразуется в 0
        }

        [TestMethod]
        public void DoubleTryParse_WithWhitespaceOnly_ReturnsFalse()
        {
            // пустая строка
            bool result = double.TryParse("   ", NumberStyles.Any, CultureInfo.InvariantCulture, out double value);

            Assert.IsFalse(result);
            Assert.AreEqual(0, value);
        }
    }

    
}
